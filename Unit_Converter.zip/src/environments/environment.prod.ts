export const environment = {
  production: true,
  application:
  {
    name: 'unit-converter',
    angular: 'Angular 10.0.8',
    bootstrap: 'Bootstrap 4.5.1',
    fontawesome: 'Font Awesome 5.14.0',
  }
};
